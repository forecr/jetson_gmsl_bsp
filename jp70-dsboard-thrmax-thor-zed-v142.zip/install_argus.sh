#!/bin/bash

sudo apt install nvidia-l4t-jetson-multimedia-api cmake build-essential pkg-config libx11-dev libgtk-3-dev libexpat1-dev libjpeg-dev libgstreamer1.0-dev
cd /usr/src/jetson_multimedia_api/argus/
mkdir build && cd build
sudo cmake .. && sudo make -j $(nproc)
sudo make install
#argus_camera
